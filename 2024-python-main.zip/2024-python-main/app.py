print("""
      
Ｘ－ｓｐｏｒｔ
      
      """)

print("1. Cadastro de alunos")
print("2. Listar alunos")
print("3. Ativar alunos")
print("4. Salvar da aplicação")

opcao_escolhida = int(input("Escolha uma opção; "))
print("Você escolheu a opção; ", opcao_escolhida)

